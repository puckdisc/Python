def friendly_greeting():
    print("Howdy, y'all!!")


def print_author(code_author):
    print(code_author, 'wrote this code.')
