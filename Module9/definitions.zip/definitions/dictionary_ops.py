def print_dictionary(hockey_dict):
    for key, value in hockey_dict.items():
        print(key, value)

