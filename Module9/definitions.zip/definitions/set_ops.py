def print_set(hockey_set):
    for x in hockey_set:
        print(x)
